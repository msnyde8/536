#include <iostream>
#include <vector>
#include <thread>
#include <math.h>

using namespace std;

unsigned long accum = 0;

void checkPrime(unsigned long x) {
	bool isPrime = true;
	for (unsigned long i=2; i<=sqrt(x); i++) {
		if (x % i == 0) {
			isPrime = false;
			break;
		}
	}
	if ( isPrime ) {
		accum += x;
	}
}


int main() {
	vector<thread> ths;
	for (unsigned int x = 1; x <= 4000000001; x += 100000000) {
		ths.push_back(thread(&checkPrime, x));
	}
	for (auto& th : ths) {
		th.join();
	}
	cout << "accum = " << accum << endl;
	return 0;
}


/*
#include <iostream>
#include <vector>
#include <thread>
#include <math.h>

using namespace std;

int accum = 0;

void increase(int x) {
	for (int j =0; j<= 1000000; j++) {
		accum = accum + 1;
	}
}

int main() {
	vector<thread> ths;
	for (int i = 1; i <= 20; i++) {
		ths.push_back(thread(&increase, i));
	}
	for (auto& th : ths) {
		th.join();
	}
	cout << "accum = " << accum << endl;
	return 0;
} 
*/

