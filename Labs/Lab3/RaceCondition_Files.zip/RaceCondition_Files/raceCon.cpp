#include <iostream>
#include <vector>
#include <thread>
#include <math.h>

using namespace std;

int accum = 0;

void square(int x) {
	for (int j = 1; j <= x*x; j++)
		accum += 1;
}

int main() {
	vector<thread> ths;
	for (int i = 1; i <= 150; i++) {
		ths.push_back(thread(&square, i));
	}
	for (auto& th : ths) {
		th.join();
	}
	cout << "accum = " << accum << endl;
	return 0;
}


/*
#include <iostream>
#include <vector>
#include <thread>
#include <math.h>

using namespace std;

int accum = 0;

void increase(int x) {
	for (int j =0; j<= 1000000; j++) {
		accum = accum + 1;
	}
}

int main() {
	vector<thread> ths;
	for (int i = 1; i <= 20; i++) {
		ths.push_back(thread(&increase, i));
	}
	for (auto& th : ths) {
		th.join();
	}
	cout << "accum = " << accum << endl;
	return 0;
} 
*/

