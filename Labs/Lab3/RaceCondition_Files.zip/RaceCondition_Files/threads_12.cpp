#include <iostream>
#include <vector>
#include <thread>

using namespace std;

void func(int x) {
	cout << "Inside thread " << x << endl;
} 

int main() {
	vector <thread> thrs;
	for (int i = 1; i<= 100; i++) {
		thrs.push_back( thread(&func, i) );
	}
	for (auto& th : thrs) {
		th.join();
	}
	cout << "Outside thread" << endl;
	return 0;
}
