#!/bin/sh

while [ -e attacking ]
do
        ./Snyder_HW_03_02_vulp < Snyder_HW_03_02_input;
done
