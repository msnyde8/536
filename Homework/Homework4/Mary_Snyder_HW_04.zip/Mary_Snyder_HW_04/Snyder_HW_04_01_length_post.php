<?php
	$result = $_POST['enterstr'];
	$length = strlen($result);
	echo "The length of string '$result' is $length\n";
?>

