<?php
	$name=$_GET['name'];
	echo "Welcome $name<br>";
	echo "<a href=\"http://xssattackexamples.com/\">Click to Enter</a>";
?>
