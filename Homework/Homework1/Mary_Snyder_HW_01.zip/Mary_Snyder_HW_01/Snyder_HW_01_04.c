#include <stdio.h>

int main ()
{
	double dNum;
	float fNum1, fNum2;
	int rtnNum = 0;
	char tChar = '!';
	char printStr[] = "Hello World";
	printf ("%s\n", printStr);

	return rtnNum;
}
